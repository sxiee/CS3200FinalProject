-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: localhost    Database: db_design
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(45) DEFAULT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `dateofbirth` date DEFAULT NULL,
  `phonenumber` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (16,'Alex','Xie','axie','axie222','axie2@gmail.com','2003-01-01','2223334445'),(18,'Bob','Green','hello122','jfsioejfhbrjn','hello123@yahoo.com','2001-04-19','8901234577'),(21,'Vivian','Smith','vvsmith','jawklhvgl','vvsmith@gmail.com','1995-06-05','3456781233'),(22,'Francis','Zhang','fzhanf','eihihHEP','fzfzf@yahoo.com','1988-08-12','7463822248'),(23,'Grace','Jiang','gjiang','jhfelasd','giang@gmail.com','2004-10-04','4564569088'),(26,'Anna','Blue','abluee12','blueblue23','ablue12@gmail.com','2003-04-09','1215784834'),(27,'Henry','John','johnhenry','hjhj9090','john.h@gmail.com','1998-07-08','1238948939'),(28,'Karen','Hopkins','khop','123hopkinsk','khop234@yahoo.com','2001-06-09','7483892893'),(29,'Julia','Bennett','benjt','ebenjul','julia.bennett@gmail.com','2000-09-01','3874939489'),(30,'Lily','Sims','lilsim','lilyilily','lilsim@yahoo.com','2005-07-03','3784917897'),(31,'Kristina','Bond','bondkristina','hjieruieP','bondkris@gmail.com','2002-11-01','834792r787'),(32,'Helen','Reese','helen.reese','helenhelenreese','helen.reese@gmail.com','1998-03-15','3874927878'),(33,'Mary','Lopez','maryxlopez','hello2345world','maryxlopez@gmail.com','1999-12-30','3840928948'),(34,'Britney','Shaw','bshaw9090','greenpurpleorangepink','bshaw9090@gmail.com','1997-02-20','8758893992');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-27 22:02:33
